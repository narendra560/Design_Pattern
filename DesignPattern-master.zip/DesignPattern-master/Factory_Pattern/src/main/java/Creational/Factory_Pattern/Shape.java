package Creational.Factory_Pattern;
public interface Shape {
	void draw();
}