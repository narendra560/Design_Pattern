package Creational.Facade_Pattern;
public interface Shape {
	void draw();
}