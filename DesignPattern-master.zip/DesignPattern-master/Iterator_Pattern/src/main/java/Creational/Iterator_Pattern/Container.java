package Creational.Iterator_Pattern;
public interface Container {
	public Iterator getIterator();
}
