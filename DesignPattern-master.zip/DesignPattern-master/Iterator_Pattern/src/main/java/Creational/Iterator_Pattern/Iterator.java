package Creational.Iterator_Pattern;
public interface Iterator {
	public boolean hasNext();
	   public Object next();
}