package Creational.Command_Pattern;

public interface Order {
	void execute();
}